MAPA ORIGINAL: respaldo previo a la variante del 2026-10-02.

Incluye los PNG originales de assets/island, el horneador y structures.gd.
El estado completo del proyecto previo está en el commit Git 8b857c7.

Para volver al mapa original: copia los PNG de esta carpeta a assets/island/ y restaura
IslandBaker.cs, structures.gd y main.gd desde esta carpeta. main.gd incluye la lógica
original que eliminaba guardados antiguos; conserva el cambio de no borrar mundos al restaurar.
Los datos del mundo anterior se mantienen en user://world/ bajo su huella original.
